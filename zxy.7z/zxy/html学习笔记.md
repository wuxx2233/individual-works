## 常见文本及区块标签

### 基本格式

```html
<!doctype html> <!--声明html文件-->
<html>
<head> <!--head进行设置，是是不可见的内容-->
  <meta charset="UTF-8"> <!--默认编码-->
  <title><!--标题必填--></title>
</head>
<body>
	<!--注释的格式-->
  <!--body标签里编辑大部分网页可视内容-->
</body>
</html>
```

### 常用标签

- 标题：格式为 `<h1></h1>` 、 `<h2></h2>` ……一直到 6 。
- 斜体：格式为 `<em></em>` 或 `<i></i>` 。
- 粗体：格式为 `<strong></strong>` 或 `<b></b>` 。
- 段落文本：格式为 `<p></p>` 。
- 上标： `<sub></sub>` 
- 下标： `<sup></sup>`
- 区块标签：常用的有 `<div></div>` 和 `<span></span>` 。
- 回车：格式为 `<br/>` 。
- 水平线：格式为 `<hr/>` 。
- 空格：格式为 `&nbsp;` 。

### 标签属性

-  `align` ： "center" 指居中。
-  `height` 、 `width` ：高度和宽度。
-  `bgcolor` 、 `color` ：背景颜色和颜色。

## 链接

格式为 `<a href="..."></a>` ， `target` 属性中 "\_blank" 表示在新窗口打开，默认的 "\_self" 是本窗口打开。

内联链接声明时格式为 `<a href="#..."></a>` ，调用时格式为 `<a name="..."></a>` 。

## 图片

格式为 `<img/>` ， `src` 属性表示图片链接（一般用相对路径）。

## 表格

```html
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <title>测试</title>
</head>
<body>
<table border="1" width="800" align="center" cellpadding="0" cellspacing="5"> <!--table声明表格，cellpadding规定单元边沿与其内容之间的空白，cellspacing规定单元之间的空间-->
  <tr height="50"> <!--行-->
    <td>&nbsp;</td> <!--每行的单元格-->
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>
</body>
</html>
```

如果要做细线表格，可以把 border 设置为 0 、 cellspacing 设置为 1 ，然后把表格背景变为黑色单元格变为白色即可。

## 表单

```html
<!doctype html>
<html>
<head>
  <meta charset="UTF-8">
  <title>测试</title>
</head>
<body>
<form action="" method="get" > <!--action一般写动态网页，method中get为地址栏传参，post为隐式传参（一般上传密码用）-->
  用户名：<input type="text"/><br/> <!--添加文本框-->
  密码：<input type="password"/><br/>
  性别：
  <input type="radio" name="sex"/>男 <!--选择-->
  <input type="radio" name="sex"/>女
  <input type="radio" name="sex"/>保密
  <br/>
  爱好：
  <input type="checkbox" name="hobby"/>音乐 <!--多选-->
  <input type="checkbox" name="hobby"/>运动
  <input type="checkbox" name="hobby"/>游戏
  <br/>
  学历：
  <select> <!--下拉框-->
    <option>请选择</option>
    <option>小学</option>
    <option>初中</option>
    <option>高中</option>
    <option>大学</option>
  </select>
  <br/>
  个人评价：<textarea rows="8" cols="10"></textarea><br/> <!--rows和cols设置行和列-->
  <input type="submit" value="确认提交"/> <!--提交-->
  <input type="reset"/> <!--重置-->
</form>
</body>
</html>
```

`<input type="image" src="..."/>` 可以用图片做按钮 。

