## 选择器

### 种类

```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>测试</title>
  <style> /*css语法格式*/
    h1{/*标签选择器*/
      color:green;
      font-size:40px;
    }
    #title{/*id选择器，只能用一次*/
      color:red;
    }
    .text{/*类选择器，记得有个点*/
      color: pink;
    }
    *{/*通用选择器，全局设置*/
      font-family: 宋体;
    }
    .out .box{/*后代选择器，注意要打一个空格*/
    /*也可以 .out div，相当于设置out下的所有div标签*/
      color: purple;
    }
    h3,h4,.box{/*编组选择器，避免冗余*/

    }
    a{
      text-decoration: none;
    }
    a:hover{/*伪类选择器，hover是其中一种*/
      color: red;
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <h1>标题</h1>
  <h2 id="title">又一个标题</h2> <!--不能再调用id="title"了-->
  <h1 class="text">再来一个</h1>
  <h2 class="text">还来一个</h2>
  <div class="out">
    <div class="box text">文章</div> <!--可以用两个 class -->
  </div>
  <div class="box">还是文章</div>
  <a href="https://www.baidu.com">百度一下</a>
</body>
</html>
```

### 优先级

标签选择器 < 类选择器  < id 选择器 < 行内样式

单选择器 < 复合选择器 < 行内样式

同类中后面覆盖前面的。

## 常见文本样式

```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <style>
    .text{
      color: blueviolet;
      font-size: 30px;
      font-family: "微软雅黑", "黑体";
      font-style: italic;/*默认normal*/
      font-weight: bold;
      line-height: 2em; /*两倍行高*/
      text-align: center;
      text-decoration: underline; /*overline 上划线，line-through 删除线，*/
      text-indent: 2em;
      overflow: hidden; /*文字超出就裁去，scroll 加上滚动条，auto 文字超出时加滚动条*/
    }
  </style>
</head>
<body>
  <div class="text">测试</div>
</body>
</html>
```

需要注意的是，给元素加 margin-top 会自动加到父级去（如果父级没有设置），此时给父级加上 overflow: hidden 即可。

## 背景样式

```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <style>
    .box{
      font-size: 50px;
      background-color: deepskyblue;
      line-height: 500px;
      background-image: url(head.jpg);
      background-repeat: no-repeat;/*默认 repeat，repeat-x x轴平铺，repeat-y y轴平铺*/
      background-position: 100px -50px;/*left center right和top, center, bottom一共九个位置
      填 px 以左上角为原点，向下为 y 正半轴，向右为 x 正半轴*/
      background:;
      /*简写：background: deepskyblue url(head.jpg) no-repeat right bottom*/
    }
    h1{
      line-height: 500px;
      background: url(wall.png);
      background-attachment: fixed;/*默认 scroll，fixed 使图片不随鼠标滚动而移动*/
    }
  </style>
</head>
<body>
  <h1>test</h1>
  <div class="box">
    测试
  </div>
</body>
</html>
```

## 盒子模型

### 边距

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <style>
    .box1,.box2,.box3{
      width: 460px;
      padding: 20px;/*
      内边距
      一个值设置上下左右，两个值第一个上下第二个左右，三个值第一个上第二个左右第三个下，四个值上右下左（顺时针）
      也可以 padding-top 单独设置
      注意 padding 的大小会增加 width, height*/
    }
    .box1{
      background: #FC9;
      opacity: 0.5 /*透明度*/
    }
    .box2{
      background: #399;
      margin: 10px;/*外边距，参数和 padding 同理*/
    }
    .box3{
      background: #ce1590;
      margin: 0 auto;/*左右居中*/
    }
  </style>
</head>
<body>
  <div class="box1">
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
  </div>
  <div class="box2">
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
  </div>
  <div class="box3">
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
    测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试测试
  </div>
</body>
</html>
```

### 边框

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <style>
    .box{
      width: 400px;
      background: #0cc;
      margin: 100px auto;
      padding: 10px;
      border-top: 10px #f72929 solid;
      border-bottom: 10px #3542b8 solid;
      border-left: 10px #f7ed66 solid;
      border-right: 10px #2edf86 solid;
      /*粗细 颜色 样式（solid 实线，dashed 虚线，dotted 点线，double 双实线）
      也可以 border 全局设置*/
    }
    .tri{/*三角*/
      width: 0px;
      height: 0px;
      border: 20px solid transparent;/*透明*/
      border-top-color: green;
    }
  </style>
</head>
<body>
  <div class="tri"></div>
  <div class="box">
    测试测试测试测试测试测试
    测试测试测试测试测试测试
    测试测试测试测试测试测试
    测试测试测试测试测试测试
    测试测试测试测试测试测试
  </div>
</body>
</html>
```

## 区块类型

1. 块级元素：
   - 代表：`div h1~6 ul ol li dl dt dd p`
   - 特性：独立显示一行，默认宽度为父级，能任意定义宽高
   - 转换：`display:block` 转换为块元素

2. 行级元素：
   - 代表：`span a strong b em i font`
   - 特性：共同显示在一行，默认宽度为子集元素宽度，不能定义宽高
   - 转换：`display:inline` 转换为块元素
3. 行级块元素：
   - 代表：`img input`
   - 特性：共同显示在一行，默认宽度为子集元素宽度，能任意定义宽高
   - `display:inline-block` 转换为块元素

4. `display none` 显示的元素变为隐藏

## 浮动

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <style>
    .out{
      width: 600px;
      height: 600px; /*如果父级元素没有高度属性，子集元素高度和就是父级元素高度，
      但是子元素添加 float 属性后，子元素高度就不能再撑开父级*/
      background: #ccc;
      margin: 100px;
    }
    .box1{
      width: 100px;
      height: 100px;
      background: red;
      float: left; /*置于顶层，左边依次对齐*/
    }
    .box2{
      width: 150px;
      height: 150px;
      background: green;
      float: right;
    }
    .box3{
      width: 200px;
      height: 200px;
      background: blue;
      clear: left; /*不允许左浮动在其上层，both 为所有浮动都不允许*/
    }
  </style>
</head>
<body>
  <div class="out">
    <div class="box1"></div>
    <div class="box2"></div>
    <div class="box3"></div>
    <div style="clear:both"></div> <!--新建一个空的清除浮动盒子就可以撑开的父级元素了-->
    <!--还有一种更简洁的方法，就是给 .out 添加 overflow: hidden 属性-->
  </div>
</body>
</html>
```

## css 样式

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>test</title>
  <link rel="stylesheet" href="style.css"/> <!--外链样式-->
  <style> /*页内样式*/

  </style>
</head>
<body>
  <h1 style="color: red;background: yellow;">测试</h1> <!--行内样式，作用区域是本标签-->
  <div class="box">
    
  </div>
</body>
</html>
```